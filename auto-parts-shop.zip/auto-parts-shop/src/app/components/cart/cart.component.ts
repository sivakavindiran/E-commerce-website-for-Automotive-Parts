import { Component } from '@angular/core';
import { CartService } from '../../services/cart.service';

declare var Razorpay: any;

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
})
export class CartComponent {
  cart = this.cartService.getCart();

  constructor(private cartService: CartService) {}

  getTotal(): number {
    return this.cart.reduce((sum, item) => sum + item.price, 0);
  }

  removeItem(item: any): void {
    this.cartService.removeFromCart(item);
  }

  checkout(): void {
    const totalAmount = this.getTotal() * 100; // in paisa

    const options = {
      key: 'rzp_test_YourRazorpayKey', // Replace with your Razorpay key
      amount: totalAmount,
      currency: 'INR',
      name: 'Auto Parts Store',
      description: 'Purchase Parts',
      handler: (response: any) => {
        alert('Payment Successful! Payment ID: ' + response.razorpay_payment_id);
        this.cartService.clearCart();
      },
      prefill: {
        name: '',
        email: ''
      },
      theme: {
        color: '#007bff'
      }
    };

    const rzp = new Razorpay(options);
    rzp.open();
  }
}

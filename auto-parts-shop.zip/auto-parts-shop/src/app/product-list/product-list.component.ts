import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
})
export class ProductListComponent {
  products = [
    { name: 'Brake Pads', price: 1500 },
    { name: 'Engine Oil', price: 500 },
    { name: 'Air Filter', price: 350 }
  ];

  addToCart(product: any) {
    alert(`Added ${product.name} to cart!`);
    
  }
}


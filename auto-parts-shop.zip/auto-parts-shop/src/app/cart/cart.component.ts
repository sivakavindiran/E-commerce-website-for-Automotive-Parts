import { Component } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
})
export class CartComponent {
  // Replace with actual cart logic or service
  cartItems = [
    { name: 'Brake Pads', price: 1500 },
  ];

  removeItem(index: number) {
    this.cartItems.splice(index, 1);
  }

  getTotal() {
    return this.cartItems.reduce((total, item) => total + item.price, 0);
  }
}

